# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent
from pacman import GameState

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState: GameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState: GameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        #uses the built in game score as a base reward
        reward = successorGameState.getScore()
        #converts the grid coordinates to a list so we can use it and creates a list
        #to store distances.
        foodList = newFood.asList()
        distances = []
        #this goes through the foodlist and stores a manhatten distance to each food
        #into the distance list, then as long as the length of the list is above 0
        #there is still food left so we keep going and calculating the reward to give
        #pacman which ive determined should be 1/ closest food + 1 so that pacman
        #prioritizes the closes food to him, and the + 1 so that if the pacman distance
        # to food is ever 0 we dont divide by 0.
        for food in foodList:
            distances.append(manhattanDistance(newPos, food))

        if len(distances) > 0:
            closestFood = min(distances)
            reward += 1 / (closestFood + 1)
        # this is the reward section for the ghosts, basically it stores the ghost position
        # for each ghost inside the ghost states, and calculates the manhatten distance
        # for each of them, storing it temporarily so it can calculate the "reward" or
        # "penalty" based off if the ghost is scared or not, it is also 1/ ghost distance + 1
        # so that pacman prioritizes getting scared ghosts if they are close, and avoiding 
        # the ghosts if they arent scared, the penalty and reward being bigger the closer they
        # are to scared ghosts and the closer they are to non scared ghosts.
        for ghost in newGhostStates:
            ghostPos = ghost.getPosition()
            ghostDist = manhattanDistance(newPos, ghostPos)
            if ghost.scaredTimer > 0:
                reward += 1 / (ghostDist + 1)
            else:
                reward -= 1 / (ghostDist + 1)

        #interesting observations: by weighting both ghost rewards negative to penalize pacman
        #for being close to a ghost at all, and weighting that more heavily that food,
        #pacman also wins all the games, and almost scored the same as this, but this
        # ultimately maximizes the score from what i found in testing, even when tweaking
        # weights and changing what he values, although, if you weight food as 0 for
        # pacman, he still wins 8/10 of the test games.

        # both the ghost "rewards" and "penalties" as well as the food "rewards" are
        # incrementing (or decrementing) the reward variable, then we return it here
        # after each cycle.
        
        return reward

def scoreEvaluationFunction(currentGameState: GameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState: GameState):

        def checkMoves(gameState, pacmanDepth, agentTurn):

            # stop if Pacman wins, loses, or we hit the search depth
            if gameState.isWin() or gameState.isLose() or pacmanDepth == self.depth:
                return self.evaluationFunction(gameState)

            # this is the part that sets who goes next (ghosts, or pacman)
            numAgents = gameState.getNumAgents()
            legalMoves = gameState.getLegalActions(agentTurn)

            nextTurn = agentTurn + 1
            nextPacmanDepth = pacmanDepth

            # loops back to pacman once the last ghost has taken its rurn.
            if nextTurn == numAgents:
                nextTurn = 0
                nextPacmanDepth += 1

            # works through pacmans turn, which is the max part of minimax. sets the "bestScore"
            # to negative infinity, so that pacman is always starting evaluation by choosing
            # the first "in reason" number (not negative infinity). then it loops through each action 
            # within the list of legal actions, and gets the "nextState" and "moveScore" for that action and agent,
            # then if the "moveScore" is higher than the previous, it will store it into "bestScore", and once
            # each action from that depth is assessed, returns the aggregated "bestScore".
            if agentTurn == 0:
                bestScore = float("-inf")

                for action in legalMoves:
                    nextState = gameState.generateSuccessor(agentTurn, action)
                    moveScore = checkMoves(nextState, nextPacmanDepth, nextTurn)

                    if moveScore > bestScore:
                        bestScore = moveScore

                return bestScore

            # works through the ghosts turn, the min part of minimax. sets the "bestScore"
            # to positive infinity, so that the ghost is always starting evaluation by choosing
            # the first "in reason" number (not infinity). then it loops through each action 
            # within the list of legal actions, and gets the "nextState" and "moveScore" for that action and agent,
            # then if the "moveScore" is lower than the previous, it will store it into "bestScore", and once
            # each action from that depth is assessed, returns the aggregated "bestScore".
            # (the min they can force)
            bestScore = float("inf")

            for action in legalMoves:
                nextState = gameState.generateSuccessor(agentTurn, action)
                moveScore = checkMoves(nextState, nextPacmanDepth, nextTurn)

                if moveScore < bestScore:
                    bestScore = moveScore

            return bestScore

        # this part is what actually controls the whole function, this basically initiates the 
        # "checkMoves" sub function to start doing its recursive call for each action in the legal actions.
        # setting the "bestScore" to -inf because it ultimately wants to only chose the "best" score
        # for pacman, so it loops through each action pacman can take, runs the "checkMoves" function
        # and for each call, assesses if the new "moveScore" is better than the "bestScore" and if it is
        # it replaces the previous with the new one, then once it finishes it returns
        # the action associated with the "bestScore".
        bestAction = None
        bestScore = float("-inf")
        legalMoves = gameState.getLegalActions(0)

        for action in legalMoves:
            nextState = gameState.generateSuccessor(0, action)
            moveScore = checkMoves(nextState, 0, 1)

            if moveScore > bestScore:
                bestScore = moveScore
                bestAction = action

        return bestAction
    
class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState: GameState):

        # same recursive helper as minimax, but it now also carries alpha and beta.
        # alpha = the best score pacman is already guaranteed somewhere above this node.
        # beta = the lowest score the ghosts can already force somewhere above this node.
        def checkMoves(gameState, pacmanDepth, agentTurn, alpha, beta):          

            # stop if Pacman wins, loses, or we hit the search depth
            if gameState.isWin() or gameState.isLose() or pacmanDepth == self.depth:
                return self.evaluationFunction(gameState)

            # this is the part that sets who goes next (ghosts, or pacman)
            numAgents = gameState.getNumAgents()
            legalMoves = gameState.getLegalActions(agentTurn)

            nextTurn = agentTurn + 1
            nextPacmanDepth = pacmanDepth

            # loops back to pacman once the last ghost has taken its turn.
            if nextTurn == numAgents:
                nextTurn = 0
                nextPacmanDepth += 1

            # pacman's turn (max). same as minimax, except after each move we check
            # if this score is already bigger than beta. if it is, a ghost above us
            # would never let the game reach this spot, so we stop looking at the rest
            # of pacman's moves here. otherwise, we raise alpha so the nodes below
            # know what pacman is already guaranteed.
            if agentTurn == 0:
                bestScore = float("-inf")

                for action in legalMoves:
                    nextState = gameState.generateSuccessor(agentTurn, action)
                    moveScore = checkMoves(nextState, nextPacmanDepth, nextTurn, alpha, beta)   

                    if moveScore > bestScore:
                        bestScore = moveScore

                    # prune: strictly greater than, never >= (the autograder requires this)
                    if bestScore > beta:                                           
                        return bestScore                                           

                    if bestScore > alpha:                                          
                        alpha = bestScore                                          

                return bestScore

            # ghost's turn (min). same as minimax, except after each move we check
            # if this score is already smaller than alpha. if it is, pacman above us
            # already has something better, so he'd never come down this path and
            # we stop looking at the rest of this ghost's moves. otherwise, we lower
            # beta so the nodes below know what the ghosts can already force.
            bestScore = float("inf")

            for action in legalMoves:
                nextState = gameState.generateSuccessor(agentTurn, action)
                moveScore = checkMoves(nextState, nextPacmanDepth, nextTurn, alpha, beta)       

                if moveScore < bestScore:
                    bestScore = moveScore

                # prune: strictly less than, never <=
                if bestScore < alpha:                                              
                    return bestScore                                              

                if bestScore < beta:                                               
                    beta = bestScore                                              

            return bestScore

        # the root, same as minimax, but we start alpha at -inf and beta at inf,
        # and after each of pacman's first moves we raise alpha. this is what lets
        # the later root moves get pruned. without it, the values come out right,
        # but we explore too many states and the autograder fails us.
        bestAction = None
        bestScore = float("-inf")
        alpha = float("-inf")                                                      
        beta = float("inf")                                                        
        legalMoves = gameState.getLegalActions(0)

        for action in legalMoves:
            nextState = gameState.generateSuccessor(0, action)
            moveScore = checkMoves(nextState, 0, 1, alpha, beta)                   

            if moveScore > bestScore:
                bestScore = moveScore
                bestAction = action

            if bestScore > alpha:                                                  
                alpha = bestScore                                                  

        return bestAction

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState: GameState):

        def checkMoves(gameState, pacmanDepth, agentTurn):

            # stop if Pacman wins, loses, or we hit the search depth
            if gameState.isWin() or gameState.isLose() or pacmanDepth == self.depth:
                return self.evaluationFunction(gameState)

            # this is the part that sets who goes next (ghosts, or pacman)
            numAgents = gameState.getNumAgents()
            legalMoves = gameState.getLegalActions(agentTurn)

            nextTurn = agentTurn + 1
            nextPacmanDepth = pacmanDepth

            # loops back to pacman once the last ghost has taken its turn.
            if nextTurn == numAgents:
                nextTurn = 0
                nextPacmanDepth += 1

            # pacman's turn (max). exactly the same as minimax: he still picks
            # the move with the highest score.
            if agentTurn == 0:
                bestScore = float("-inf")

                for action in legalMoves:
                    nextState = gameState.generateSuccessor(agentTurn, action)
                    moveScore = checkMoves(nextState, nextPacmanDepth, nextTurn)

                    if moveScore > bestScore:
                        bestScore = moveScore

                return bestScore

            # ghost's turn (chance). this is the only real change from minimax.
            # instead of assuming the ghost picks the worst move for pacman (min),
            # we assume it picks any of its legal moves at random with equal odds,
            # so the value of this node is the average score across all of its moves.
            # we add up every move's score, then divide by how many moves there were.
            totalScore = 0                                                        

            for action in legalMoves:
                nextState = gameState.generateSuccessor(agentTurn, action)
                moveScore = checkMoves(nextState, nextPacmanDepth, nextTurn)

                totalScore += moveScore                                           

            # float() makes sure we never get truncated integer division
            return totalScore / float(len(legalMoves))                           

        # the root, exactly the same as minimax: try each of pacman's moves,
        # score it with checkMoves, and keep the action with the best score.
        bestAction = None
        bestScore = float("-inf")
        legalMoves = gameState.getLegalActions(0)

        for action in legalMoves:
            nextState = gameState.generateSuccessor(0, action)
            moveScore = checkMoves(nextState, 0, 1)

            if moveScore > bestScore:
                bestScore = moveScore
                bestAction = action

        return bestAction

def betterEvaluationFunction(currentGameState: GameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION: I wrote most of what the function does in the notes below, but basically my function takes alot into account,
    for the sake of a useful description i will say it mainly focuses on food, ghosts when close enough to be a danger when they are
    not scared, ghosts when close enough to be eaten when scared, and capsule distance to see if a non scared ghost is a problem,
    or if we can eat a capsule before it gets to us.
    """
    "*** YOUR CODE HERE ***"

    # starts with the built in game score as the base reward, then gets all of the
    # information i actually care about for evaluating the state, pacmans position,
    # where all the food is, the ghost states, and where the capsules are.
    reward = currentGameState.getScore()
    pacmanPos = currentGameState.getPacmanPosition()
    foodList = currentGameState.getFood().asList()
    ghostStates = currentGameState.getGhostStates()
    capsules = currentGameState.getCapsules()

    # this part gets the manhattan distance to every food on the board and stores
    # them in a list, then as long as there is still food left it finds the closest one.
    # i penalize the number of food left pretty heavily because i want pacman to value
    # actually clearing the board, and i also penalize the distance to the closest food
    # so that he is still being pushed towards it instead of just wandering around.
    foodDistances = []

    for food in foodList:
        foodDistances.append(manhattanDistance(pacmanPos, food))

    if len(foodDistances) > 0:
        closestFood = min(foodDistances)
        reward -= len(foodList) * 100
        reward -= closestFood

    # this does basically the same thing for capsules, it stores the distance from
    # pacman to every capsule so that later i can use the closest one to decide if
    # pacman has a realistic chance of reaching a power pellet before a ghost gets him.
    capsuleDistances = []

    for capsule in capsules:
        capsuleDistances.append(manhattanDistance(pacmanPos, capsule))

    # this is the ghost section. for each ghost it gets the postion and distance from
    # pacman, then handles scared and non scared ghosts differently.
    for ghost in ghostStates:

        ghostPos = ghost.getPosition()
        ghostDistance = manhattanDistance(pacmanPos, ghostPos)

        # if the ghost is scared, i only give pacman a reward for going sfter it if the
        # ghost is actually close enough that he could reach it before the scared timer
        # runs out. i didnt want him abandoning food to chase a ghost across the whole map
        # just because it happened to be scared.
        if ghost.scaredTimer > 0:

            if ghostDistance <= ghost.scaredTimer:
                reward += 20 / (ghostDistance + 1)

        else:

            # if the ghost isnt scared, i check whether there is a capsule on the board
            # that pacman can reach before the ghost could realistically reach him.
            # if there is, i dont punish him as heavily for the ghost being nearby because
            # he has a way to make the ghost scared before it becomes a major problem.
            canReachCapsule = False

            if len(capsuleDistances) > 0:
                closestCapsule = min(capsuleDistances)

                if closestCapsule < ghostDistance:
                    canReachCapsule = True

            # if there isnt a capsule he can reach first, then i start penalizing the ghost
            # based on how close it is. the closer the ghost is, the bigger the penalty is,
            # because survival matters more than trying to grab food if the ghost is about
            # to catch him.
            if not canReachCapsule:

                if ghostDistance <= 1:
                    reward -= 50

                elif ghostDistance <= 2:
                    reward -= 10

                elif ghostDistance <= 5:
                    reward -= 2 / (ghostDistance + 1)

    # interesting observations/testing:
    # i spent a while tweaking pretty much all of the values in this function because
    # pacman kept doing this weird thing where he would navigate perfectly fine towards
    # food, get right next to it, and then randomly freeze until the ghost got closer.
    # the weird part was that it mostly happened when the ghost was on the other side
    # of the board, and once the ghost got close enough pacman would suddenly start moving
    # normally again.

    # i tried weighting the built in score more heavily because i thought maybe pacman
    # wasnt valuing the score penalty from standing still enough, so i multiplied the
    # score by larger values to try to make moving and actually making progress matter more.
    # that didnt really fix the freezing behavior.

    # i also tried changing the dood weights a bunch. i made the penalty for the number
    # of food left much larger, changed how heavily closest food distance was weighted,
    # and tried using reciprocal distance again. the idea was to make actually eating a
    # food much more valuable than just standing next to it, but pacman would still
    # occasionally freeze even when the food reward was weighted extremely heavily.

    # i also experimented with the ghost evaluation because the freezing almost always
    # happened when the ghost was really far away. i tried making pacman care more about
    # approaching a far away ghost, changing the distance ranges where ghost penalties
    # kicked in, and changing the penalty values themselves. none of those completely
    # removed the behavior either.

    # i also thought about directly penalizing pacman for choosing STOP, but this function
    # only receives a game state and not the action that created it, so there isnt really
    # a reliable way inside this function to know that the state came from pacman stopping.
    # trying to keep a counter for how long he had been stopped also wouldnt work very well
    # because the search evaluates a bunch of hypothetical states, so the counter would
    # start counting search branches instead of actual turns in the game.

    # after testing the different values and behaviors, i ended up keeping this version
    # because even though pacman still occasionally freezes when the ghost is far away,
    # he still consistently wins. the evaluation is doing what i actualy care about:
    # clearing food, avoiding dangerous ghosts, chasing scared ghosts when they are
    # realistically reachable, and using capsules as a possible escape when a normal
    # ghost is close.

    return reward

# Abbreviation
better = betterEvaluationFunction
